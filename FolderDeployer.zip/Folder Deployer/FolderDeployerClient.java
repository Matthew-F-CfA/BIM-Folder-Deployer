import java.util.Vector;
import java.io.*;
import java.net.*;

class FolderDeployerClient {
  static String strFolder="";
  static String fSep="";
  static Vector vecFolders=new Vector();
  static Vector vecFiles=new Vector();

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  java FolderDeployerClient <server address> <server port> <folder to deploy from>");

        return;
      }

      String strServerAddress=args[0];

      String strServerPort=args[1];
      int intServerPort=Integer.parseInt(strServerPort);

      strFolder=args[2];

      File fileFolder=new File(strFolder);

      if(!fileFolder.exists()) {
        System.out.println("Folder doesn't exist.");

        return;
      }

      if(!fileFolder.isDirectory()) {
        System.out.println("Folder isn't a directory.");

        return;
      }

      strFolder=fileFolder.getAbsolutePath();
      fSep=System.getProperty("file.separator");
      if(!strFolder.endsWith(fSep))
        strFolder=strFolder+fSep;

      iterateFolder(fileFolder);

      Socket sock=new Socket(strServerAddress, intServerPort);

//      DataInputStream dis=new DataInputStream(sock.getInputStream());
      DataOutputStream dos=new DataOutputStream(sock.getOutputStream());

      dos.writeInt(vecFolders.size());
      dos.writeInt(vecFiles.size());

      for(int i=0;i<vecFolders.size();i++) {
        String strFolderName=(String)vecFolders.elementAt(i);

        dos.writeInt(strFolderName.length());

        dos.writeBytes(strFolderName);

        dos.flush();
      }

      for(int i=0;i<vecFiles.size();i++) {
        String strFilePath=(String)vecFiles.elementAt(i);

        dos.writeInt(strFilePath.length());

        dos.writeBytes(strFilePath);

        dos.flush();

        File fileFile=new File(strFolder+strFilePath);

        byte bbuf[]=new byte[(int)fileFile.length()];

        dos.writeInt(bbuf.length);

        dos.flush();

        BufferedInputStream bis=new BufferedInputStream(new FileInputStream(fileFile));

        bis.read(bbuf, 0, bbuf.length);

        bis.close();

        dos.write(bbuf, 0, bbuf.length);

        dos.flush();
      }

      sock.close();

      System.out.println("Transfer successful.");
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void iterateFolder(File fileFolder) throws Exception {
    String strIterateFolder=fileFolder.getAbsolutePath();
    if(!strIterateFolder.endsWith(fSep))
      strIterateFolder=strIterateFolder+fSep;

    if(strFolder.length()==strIterateFolder.length())
      strIterateFolder="";
    else
      strIterateFolder=strIterateFolder.substring(strFolder.length());

    File fileList[]=fileFolder.listFiles();
    for(int i=0;i<fileList.length;i++) {
      if(fileList[i].isDirectory()) {
        vecFolders.addElement(strIterateFolder+fSep+fileList[i].getName());

        iterateFolder(fileList[i]);
      }
      else {
        vecFiles.addElement(strIterateFolder+fSep+fileList[i].getName());
      }
    }
  }
}