import java.io.*;
import java.net.*;

class FolderDeployerServer {

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  java FolderDeployerServer <port number> <folder to deploy to>");

        return;
      }

      String strPort=args[0];
      int intPort=Integer.parseInt(strPort);

      String strFolder=args[1];
      String fSep=System.getProperty("file.separator");
      if(!strFolder.endsWith(fSep))
        strFolder=strFolder+fSep;

      File fileFolder=new File(strFolder);

      if(!fileFolder.exists()) {
        System.out.println("Folder doesn't exist.");

        return;
      }

      if(!fileFolder.isDirectory()) {
        System.out.println("Folder isn't a directory.");

        return;
      }

      ServerSocket serveSock=new ServerSocket(intPort);

      Socket clientSock=serveSock.accept();

      DataInputStream dis=new DataInputStream(clientSock.getInputStream());
//      DataOutputStream dos=new DataOutputStream(clientSock.getOutputStream());

      int intFolders=dis.readInt();
      int intFiles=dis.readInt();

      for(int i=0;i<intFolders;i++) {
        int intFolderLength=dis.readInt();
        byte bbuf[]=new byte[intFolderLength];

        dis.readFully(bbuf);

        String strFolderPath=new String(bbuf);

        if(strFolderPath.startsWith(fSep))
          strFolderPath=strFolderPath.substring(fSep.length());

        strFolderPath=strFolder+strFolderPath;

        File fileNewFolder=new File(strFolderPath);

        if(!fileNewFolder.getAbsolutePath().startsWith(fileFolder.getAbsolutePath())) {
          System.out.println("Invalid folder path encountered.");

          return;
        }

        fileNewFolder.mkdirs();
      }

      for(int i=0;i<intFiles;i++) {
        int intFilePathLength=dis.readInt();
        byte bbuf[]=new byte[intFilePathLength];

        dis.readFully(bbuf);

        String strFilePath=new String(bbuf);

        if(strFilePath.startsWith(fSep))
          strFilePath=strFilePath.substring(fSep.length());

        strFilePath=strFolder+strFilePath;

        File fileNewFile=new File(strFilePath);

        int intFileLength=dis.readInt();
        bbuf=new byte[intFileLength];

        dis.readFully(bbuf);

        BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(fileNewFile));

        bos.write(bbuf, 0, bbuf.length);

        bos.close();
      }

      clientSock.close();

      System.out.println("Transfer successful.");
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}